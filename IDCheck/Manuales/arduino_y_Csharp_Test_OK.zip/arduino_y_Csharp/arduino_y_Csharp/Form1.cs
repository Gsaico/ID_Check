﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;

using System.Windows.Forms;
using System.IO.Ports;
using arduino_y_Csharp.Properties;

namespace arduino_y_Csharp
{
    public partial class Form1 : Form
    {

       

        public Form1()
        {
            InitializeComponent();

         
            serialPort2.PortName = "COM6";
            serialPort2.BaudRate = 9600;

            try
            {
                serialPort2.Open();
            }
            catch (Exception err)
            {
                MessageBox.Show("No se pudo conectar a el puerto especificado\n" + err, "Error");
            }
        }

        private void btnEncender_Click(object sender, EventArgs e)
        {
            serialPort2.Write("1");
            textBox1.Text = "LED is on!";
            btnEncender.Enabled = false;
            btnApagar.Enabled = true;
                  
        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            serialPort2.Write("0");
            textBox1.Text = "LED is off!";
            btnEncender.Enabled = true;
            btnApagar.Enabled = false;
         
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort2.IsOpen) serialPort2.Close();
        }
    }
}
